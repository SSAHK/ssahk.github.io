+Gallery
========

A responsive javascript based image gallery driven by photos from a 3rd party source.

The Quick 'n' Dirty Edition
===========================

1. Download the files 
2. Make sure you have the latest and greatest Jquery running on your site (>1.7).
3. Get  your Facebook, Google, or  Flickr  User ID. If using Flickr you will also need a Flickr API Key (http://www.flickr.com/services/apps/create/apply). 
4. Add this code to your site: 

		<link rel="stylesheet" href="css/plusgallery.css" />
		<script src="js/plusgallery.js"></script>
		<!-- The HTML -->
  	<div id="plusgallery" data-type="google" data-userid="mygoogleuserid"><!-- +Gallery http://www.plusgallery.net/ --></div>
	
	
	Read more about optional data attributes and how to use them at http://www.plusgallery.net